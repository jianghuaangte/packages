一、程序说明
    1. vnt-cli vnt的命令行程序
    2. vn-link-cli  功能和vnt-cli基本一致，但是不依赖tun、不改变本地路由、不需要管理员/root权限

二、使用说明
    使用-k参数构建虚拟网络


1. Program Description
    a. vnt-cli: Command-line program for VNT.
    b. vn-link-cli: Functions similarly to vnt-cli, but does not depend on TUN, does not change local routing, and does not require administrator/root permissions.

2. Instructions for Use
    Use the -k parameter to create a virtual network.